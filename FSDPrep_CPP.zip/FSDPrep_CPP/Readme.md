Name: Jasmine Islam 
Chapter 2: Ex 2.3, Ex 2.5
Chapter 4: Ex 4.17, Ex 4.20
Chapter 6: Ex 6.1, Ex 6.2, Ex 6.3
Chapter 7 : Ex 7.1, Ex 7.4,
Chapter 9 : Ex 9.1
Chapter 11 : Ex 11.3, Ex 11.4, Ex 11.8,
Chapter 12 : Ex 12.1
Chapter 14 : Ex 14.3, Ex 14.14
Chapter 15 : Ex 15.1, Ex 15.2, Ex 15.3

The cpp files are named for each of the problems, i.e. answer for 2.3 is on file twoThree.cpp

Mac executable files are included for most of the problems, except 11.3, 12.1.
